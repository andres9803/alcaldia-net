﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace alcaldia
{
    public class Sesion
    {

        public static long documentoSesion;
        public static string nombreSesion;
        public static string rolSesion;
    }
}
